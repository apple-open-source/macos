# please insert nothing before this line: -*- mode: cperl; cperl-indent-level: 4; cperl-continued-statement-offset: 4; indent-tabs-mode: nil -*-
print "Content-type: text/html\n\n";

print "Hello World<br>\n";
