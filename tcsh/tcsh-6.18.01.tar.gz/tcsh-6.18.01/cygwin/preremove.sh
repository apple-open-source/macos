#!/bin/bash
rm -f /usr/bin/csh /usr/bin/csh.exe /usr/bin/csh.lnk /usr/share/man/man1/csh.1*
