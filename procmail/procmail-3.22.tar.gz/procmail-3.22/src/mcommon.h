/*$Id: mcommon.h,v 1.2 1999/04/19 06:42:20 guenther Exp $*/

void
 qsignal P((const int sig,void(*action)(void)));
