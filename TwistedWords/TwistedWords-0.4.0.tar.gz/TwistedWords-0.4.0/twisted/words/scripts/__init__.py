"words scripts"
