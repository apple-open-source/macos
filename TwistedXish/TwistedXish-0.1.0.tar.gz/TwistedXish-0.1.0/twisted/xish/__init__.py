
# Copyright (c) 2001-2004 Twisted Matrix Laboratories.
# See LICENSE for details.


"""

Twisted X-ish: XML-ish DOM and XPath-ish engine

"""

__version__ = '0.1.0'
