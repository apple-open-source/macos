tinyMCE.addI18n('sr.paste_dlg',{
text_title:"Koristite CTRL+V na tipkovnici da zalepite tekst u prozor.",
text_linebreaks:"Zadr\u017Ei prelome",
word_title:"Koristite CTRL+V na tipkovnici da zalepite tekst u prozor."
});