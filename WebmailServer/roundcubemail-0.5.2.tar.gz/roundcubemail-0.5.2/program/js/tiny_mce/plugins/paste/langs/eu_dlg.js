tinyMCE.addI18n('eu.paste_dlg',{
text_title:"Erabili CTRL+V testua lehioan itsasteko.",
text_linebreaks:"Mantendu lerro-jauziak",
word_title:"Erabili CTRL+V testua lehioan itsasteko.."
});