tinyMCE.addI18n('hu.searchreplace_dlg',{
searchnext_desc:"Keres\u00E9s megint",
notfound:"A keres\u00E9s v\u00E9get \u00E9rt. A keresett sz\u00F6vegr\u00E9sz nem tal\u00E1lhat\u00F3.",
search_title:"Keres\u00E9s",
replace_title:"Keres\u00E9s/Csere",
allreplaced:"A keresett r\u00E9szsz\u00F6veg minden el\u0151fordul\u00E1sa cser\u00E9lve lett.",
findwhat:"Mit cser\u00E9l",
replacewith:"Mire cser\u00E9l",
direction:"Ir\u00E1ny",
up:"Fel",
down:"Le",
mcase:"Kis- \u00E9s nagybet\u0171k megk\u00FCl\u00F6nb\u00F6ztet\u00E9se",
findnext:"Keres\u00E9s",
replace:"Csere",
replaceall:"Minden tal\u00E1lat cser\u00E9je"
});