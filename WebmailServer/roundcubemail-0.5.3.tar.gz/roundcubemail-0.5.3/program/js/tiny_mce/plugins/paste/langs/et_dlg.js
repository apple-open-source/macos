tinyMCE.addI18n('et.paste_dlg',{
text_title:"Vajuta CTRL+V oma klaviatuuril teksti aknasse kleepimiseks.",
text_linebreaks:"J\u00E4ta reavahetused",
word_title:"Vajuta CTRL+V oma klaviatuuril teksti aknasse kleepimiseks."
});