package baseA;

sub dummy { 2 };

1;
