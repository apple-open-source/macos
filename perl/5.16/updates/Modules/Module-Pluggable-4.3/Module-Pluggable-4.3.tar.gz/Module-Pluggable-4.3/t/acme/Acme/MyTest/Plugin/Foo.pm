package Acme::MyTest::Plugin::Foo;


use strict;


1;


