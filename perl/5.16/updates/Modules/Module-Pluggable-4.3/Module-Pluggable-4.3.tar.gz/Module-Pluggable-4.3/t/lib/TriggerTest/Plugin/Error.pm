package TriggerTest::Plugin::Error;

