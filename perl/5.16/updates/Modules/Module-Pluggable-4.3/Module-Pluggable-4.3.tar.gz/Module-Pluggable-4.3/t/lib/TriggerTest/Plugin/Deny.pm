package TriggerTest::Plugin::Deny;

1;