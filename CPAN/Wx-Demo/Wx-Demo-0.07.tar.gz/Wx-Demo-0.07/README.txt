Wx::Demo is a separate package for the wxPerl demo, previously bundled
with the wxPerl distribution.

Copyright (c) 2000-2006 Mattia Barbon.
This package is free software; you can redistribute it and/or
modify it under the same terms as Perl itself.

To install:

perl Makefile.PL
make
make test
make install

then run

wxperl_demo.pl

BUGS

The examples are sometimes inconsistent and incomplete. This will be fixed.
It is no worst than what was previously inside the wxPerl distribution.