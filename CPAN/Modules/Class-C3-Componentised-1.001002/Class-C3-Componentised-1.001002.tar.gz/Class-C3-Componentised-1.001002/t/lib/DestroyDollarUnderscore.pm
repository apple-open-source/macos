package DestroyDollarUnderscore;
use strict;
use warnings;

undef ($_);

1;
