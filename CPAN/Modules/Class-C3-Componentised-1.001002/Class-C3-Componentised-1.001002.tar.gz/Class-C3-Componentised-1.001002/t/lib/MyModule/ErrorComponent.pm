package # hide from PAUSE
    MyModule::ErrorComponent;
use strict;
use warnings;

# this is missing on purpose
# 1;

