package SuperInheritedGroups;
use strict;
use warnings;
use base 'BaseInheritedGroups';

1;
