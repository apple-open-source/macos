package MyApp::Help;
use base 'App::CLI::Command';

use strict;
use warnings;

sub run {
    my ( $self, @args ) = @_;
}

1;
