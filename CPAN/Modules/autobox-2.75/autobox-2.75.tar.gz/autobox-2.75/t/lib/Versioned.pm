package #
    Versioned;

use strict;
use warnings;

our $VERSION = '0.42';

sub test { $VERSION }

1;
