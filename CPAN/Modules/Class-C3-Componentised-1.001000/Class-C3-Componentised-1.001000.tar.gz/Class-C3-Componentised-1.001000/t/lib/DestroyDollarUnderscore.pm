package DestroyDollarUnderscore;

use warnings;
use strict;

undef ($_);

1;
