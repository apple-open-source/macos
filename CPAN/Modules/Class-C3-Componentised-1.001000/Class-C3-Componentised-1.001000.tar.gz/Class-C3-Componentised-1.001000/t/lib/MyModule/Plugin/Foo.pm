package # hide from pause
  MyModule::Plugin::Foo;

use Class::C3;

sub message { 
  "Foo";
}

1;
