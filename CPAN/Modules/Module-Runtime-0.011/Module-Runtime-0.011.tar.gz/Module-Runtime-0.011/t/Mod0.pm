package t::Mod0;

{ use 5.006; }
use warnings;
use strict;

our $VERSION = 1;

"t::Mod0 return";
