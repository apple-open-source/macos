
package MyMetaClass::Attribute;

use strict;
use warnings;

use parent 'Class::MOP::Attribute';

1;
