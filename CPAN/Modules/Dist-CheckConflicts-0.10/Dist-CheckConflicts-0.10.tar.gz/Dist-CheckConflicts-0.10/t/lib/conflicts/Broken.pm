package Broken;

die 'this module is utterly broken';
