package Bar::Three;
use strict;
use warnings;

our $VERSION = 0.02;

1;
