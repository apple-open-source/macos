package Foo::Thing;
use strict;
use warnings;

our $VERSION = 0.02;

warn "Loading Foo::Thing";

1;
