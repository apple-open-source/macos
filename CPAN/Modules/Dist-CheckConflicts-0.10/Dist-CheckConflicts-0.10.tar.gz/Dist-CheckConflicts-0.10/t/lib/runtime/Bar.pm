package Bar;
use strict;
use warnings;

use Bar::Foo;
use Bar::Baz;

use Bar::Conflicts;

use Bar::Bar;
use Bar::Quux;

1;
