package Foo;
use strict;
use warnings;

use Foo::Foo;
use Foo::Baz;

use Foo::Conflicts;

use Foo::Bar;
use Foo::Quux;

1;
