package autobox_scope_2;

sub test {
    my $array = [];
    $array->test();
}

1;
