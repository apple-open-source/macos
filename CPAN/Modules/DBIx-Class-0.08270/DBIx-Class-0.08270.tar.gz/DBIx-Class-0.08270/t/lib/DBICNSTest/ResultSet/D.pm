package DBICNSTest::ResultSet::D;

use warnings;
use strict;

1;
