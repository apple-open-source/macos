my %waaah;

print (var_name(0, \%waaah) eq '%waaah' ? "ok 5\n" : "not ok 5\n");

do "./vn-inc-2.pl";
