package C;

sub method { 1 }

1;

