package J;

sub foo { 1 }

sub can { die "J->can threw an exception" }

1;
