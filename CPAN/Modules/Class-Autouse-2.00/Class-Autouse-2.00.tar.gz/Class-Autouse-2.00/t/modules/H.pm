package H;

sub bar { 1 }

1;
