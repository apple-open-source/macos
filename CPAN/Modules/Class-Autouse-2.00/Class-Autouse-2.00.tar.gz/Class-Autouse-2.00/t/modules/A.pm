package A;

use base 'Class::Autouse::Parent';

1;
