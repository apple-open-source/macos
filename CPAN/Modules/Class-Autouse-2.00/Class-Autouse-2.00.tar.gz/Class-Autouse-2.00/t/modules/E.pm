package E;

use strict;

# Just define the foo method, to be called from F::foo
sub foo { 'Return value from E->foo' }

1;

