package T::B;

sub method { 1 }

1;
