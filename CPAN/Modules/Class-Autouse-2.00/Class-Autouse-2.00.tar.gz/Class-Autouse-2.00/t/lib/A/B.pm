package A::B;

BEGIN {
	$loaded= 1;
}

sub foo { 'bar' }

1;
