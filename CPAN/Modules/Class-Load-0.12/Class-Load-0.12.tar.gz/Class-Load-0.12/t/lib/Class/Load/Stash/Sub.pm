package Class::Load::Stash::Sub;
use strict;
use warnings;

sub ver_test { return "Class::Load::Stash ver $Class::Load::Stash::VERSION" }

1;
