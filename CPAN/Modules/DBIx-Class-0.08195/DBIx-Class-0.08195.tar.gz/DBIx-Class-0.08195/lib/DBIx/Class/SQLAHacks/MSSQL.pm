package # Hide from PAUSE
  DBIx::Class::SQLAHacks::MSSQL;

use base qw( DBIx::Class::SQLMaker::MSSQL );

1;
