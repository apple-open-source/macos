#!/usr/bin/perl -w
use strict;
use Rule3;

my $parser = new Rule3();
$parser->Run;
