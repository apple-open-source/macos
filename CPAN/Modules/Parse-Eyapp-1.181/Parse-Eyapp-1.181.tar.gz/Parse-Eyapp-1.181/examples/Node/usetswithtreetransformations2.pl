#!/usr/bin/perl -w
use strict;
use TSwithtreetransformations2;
use Parse::Eyapp::Treeregexp;

my $parser = TSwithtreetransformations2->new();
$parser->Run;
