package SyntaxError;
use namespace::clean;
sub foo { if }
1;
