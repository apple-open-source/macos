package MyApp::Help;
use base 'App::CLI::Command';



1;
