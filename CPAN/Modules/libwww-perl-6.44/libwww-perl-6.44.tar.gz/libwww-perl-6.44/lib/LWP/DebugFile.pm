package LWP::DebugFile;

our $VERSION = '6.44';

# legacy stub

1;
