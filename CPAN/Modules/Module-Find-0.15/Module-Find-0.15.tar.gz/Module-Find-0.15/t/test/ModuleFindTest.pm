package ModuleFindTest;

$ModuleFindTest::loaded = 1;
