package ModuleFindTest::SubMod;

$ModuleFindTest::SubMod::loaded = 1;
