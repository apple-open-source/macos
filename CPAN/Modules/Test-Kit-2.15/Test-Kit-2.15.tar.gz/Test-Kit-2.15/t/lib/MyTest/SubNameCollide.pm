package MyTest::SubNameCollide;

use strict;
use warnings;

use Test::Kit;

include 'Test::More';

include 'Test::Simple';

1;
