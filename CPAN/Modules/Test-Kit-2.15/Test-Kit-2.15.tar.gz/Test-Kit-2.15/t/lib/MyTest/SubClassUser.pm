package MyTest::SubClassUser;

use strict;
use warnings;

use MyTest::TestKitSubClass;

include 'Test::More';

1;
