package MyTest::IncludeList;

use strict;
use warnings;

use Test::Kit;

include 'Test::More', 'Test::Warn', 'Test::Exception';

1;
