package MyTest::DataDumper;

use strict;
use warnings;

use Test::Kit;

include 'Test::More';

include 'Test::Warn';

include 'Data::Dumper';

1;
