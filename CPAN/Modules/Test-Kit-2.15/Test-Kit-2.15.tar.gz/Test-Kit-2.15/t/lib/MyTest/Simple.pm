package MyTest::Simple;

use strict;
use warnings;

use Test::Kit;

include 'Test::More';
include 'Test::Warn';

1;
