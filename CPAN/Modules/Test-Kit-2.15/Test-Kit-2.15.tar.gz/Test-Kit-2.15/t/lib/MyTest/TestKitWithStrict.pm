package MyTest::TestKitWithStrict;

use strict;
use warnings;

use Test::Kit;

include 'strict';

include 'Test::More';

1;
