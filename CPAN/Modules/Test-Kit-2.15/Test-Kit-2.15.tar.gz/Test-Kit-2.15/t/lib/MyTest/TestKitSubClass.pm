package MyTest::TestKitSubClass;

use strict;
use warnings;

use Test::Kit;
use parent 'Test::Kit';

our @EXPORT = @Test::Kit::EXPORT;

1;
