package MyTest::Basic;

use strict;
use warnings;

use Test::Kit;

include 'Test::More';

1;
