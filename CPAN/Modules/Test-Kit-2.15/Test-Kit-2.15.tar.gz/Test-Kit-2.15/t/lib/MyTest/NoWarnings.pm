package MyTest::NoWarnings;

use strict;
use warnings;

use Test::Kit;

include 'Test::More';

include 'Test::NoWarnings';

1;
