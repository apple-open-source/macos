package MyTest::TestKitWithWarnings;

use strict;
use warnings;

use Test::Kit;

include 'warnings';

include 'Test::More';

1;
