no indirect ":fatal";

1;
