package My::Annoyingly::Long::Name::Space;
use Moose;
1;
