use MooseX::Method::Signatures;
use strict;
use warnings;

method meth1 (SomeRandomTCThatDoesntExist $e) {
}

1;

