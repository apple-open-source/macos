package T;

sub method { 1 }

1;
