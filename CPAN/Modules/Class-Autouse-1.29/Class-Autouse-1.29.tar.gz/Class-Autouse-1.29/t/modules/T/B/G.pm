package T::B::G;

sub method { 1 }

1;
