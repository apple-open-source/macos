symlink "os/darwin.c", "OS.c" || die "Could not link os/darwin.c to os/OS.c\n";
