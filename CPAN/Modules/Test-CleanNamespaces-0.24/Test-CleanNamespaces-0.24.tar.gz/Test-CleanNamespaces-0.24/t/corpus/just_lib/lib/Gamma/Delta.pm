package Gamma::Delta;
1;
