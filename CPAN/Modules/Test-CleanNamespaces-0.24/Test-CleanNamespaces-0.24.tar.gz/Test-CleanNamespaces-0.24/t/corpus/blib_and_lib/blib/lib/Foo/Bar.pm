package Foo::Bar;
1;
