package LWP::Protocol::ldaps;

use strict ;
use base 'LWP::Protocol::ldap' ;

1;
