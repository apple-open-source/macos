package chicken;

use egg;

1;
__END__