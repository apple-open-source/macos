package outer_diamond_W;

use outer_diamond_S;

1;
__END__