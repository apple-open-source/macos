package Foo::Bar::Baz;

use strict;
use warnings;

1;
