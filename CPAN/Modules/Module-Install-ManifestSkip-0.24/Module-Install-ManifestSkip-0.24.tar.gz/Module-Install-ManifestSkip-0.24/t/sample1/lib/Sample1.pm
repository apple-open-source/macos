package Sample1;
use 5.005005;
$Sample1::VERSION = '1.23';
