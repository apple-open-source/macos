int x;
x() {
  char x[20];
}

int f() {
  x = 4;
}
