#!/usr/bin/perl -w
use Incremental;

Incremental->new->YYParse;
