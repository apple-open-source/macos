typedef char *string[10];
     
main()
{
   string text = { "Thunderbird", };
 
   printf("%s\n", text[0]);
}


