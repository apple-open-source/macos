#!/usr/bin/perl -w
use strict;
use Postfix;

Postfix->main;
