package I;

sub foo { 1 }

die "This is an expected error";

1;
