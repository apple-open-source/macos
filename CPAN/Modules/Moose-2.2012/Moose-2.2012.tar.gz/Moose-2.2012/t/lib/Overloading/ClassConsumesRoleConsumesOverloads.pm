package Overloading::ClassConsumesRoleConsumesOverloads;

use Moose;

with 'Overloading::RoleConsumesOverloads';

1;
