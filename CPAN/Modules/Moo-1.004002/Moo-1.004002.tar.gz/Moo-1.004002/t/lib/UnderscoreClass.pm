package UnderscoreClass;
use Moo;
with qw(UnderscoreRole);
sub c1 { 'c1' };
1;
