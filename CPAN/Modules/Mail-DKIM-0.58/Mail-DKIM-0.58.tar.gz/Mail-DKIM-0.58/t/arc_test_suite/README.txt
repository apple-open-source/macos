These files are included from the arc_test_suite Copyright <2017> ValiMail Inc.

https://github.com/ValiMail/arc_test_suite.git

