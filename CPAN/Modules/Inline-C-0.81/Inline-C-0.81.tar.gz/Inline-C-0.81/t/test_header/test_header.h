
/* used by 33intended_double_quotes.t */

#define TEST_DEFINE 2113
