
/* used by 32include_dirs_double_quotes.t and 33intended_double_quotes.t */

#define TEST_DEFINE 2112
