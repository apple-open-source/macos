/* This file used by t/19INC.t */

#include <stdio.h>

