package FSGlobby;

sub new {
    my $class = shift;
    return bless {}, $class;
}

1;

__DATA__
File:
URL:
Description:
Columns:
Intended-For:
Written-By:
Line-Count:
Last-Updated:
