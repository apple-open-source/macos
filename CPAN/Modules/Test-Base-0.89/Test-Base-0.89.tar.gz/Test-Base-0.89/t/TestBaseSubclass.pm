package TestBaseSubclass;
use Test::Base -Base;
