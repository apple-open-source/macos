# FIXME Disabled due to unsolved issues, ask theorbtwo
#require Module::Install::Pod::Inherit;
#PodInherit();

# keep the Makefile.PL eval happy
1;
