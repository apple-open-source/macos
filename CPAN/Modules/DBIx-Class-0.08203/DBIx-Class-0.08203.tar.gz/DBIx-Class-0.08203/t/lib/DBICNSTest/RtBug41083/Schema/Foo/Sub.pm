package DBICNSTest::RtBug41083::Schema::Foo::Sub;
use strict;
use warnings;
use base 'DBICNSTest::RtBug41083::Schema::Foo';
1;
