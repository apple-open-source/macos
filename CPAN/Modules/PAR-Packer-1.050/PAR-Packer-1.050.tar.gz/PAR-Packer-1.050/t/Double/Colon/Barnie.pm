package Double::Colon::Barnie;
1;
