package Foo;
use Foo::Bar;
sub foo {
    Foo::Bar->foo();
}
1;
