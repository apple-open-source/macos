package Foo::Bar;
sub foo { print "hello\n"; }
1;
