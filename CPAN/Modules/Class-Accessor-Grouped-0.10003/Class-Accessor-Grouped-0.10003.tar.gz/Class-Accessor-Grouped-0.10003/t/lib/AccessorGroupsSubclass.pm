package AccessorGroupsSubclass;
use strict;
use warnings;
use base 'AccessorGroups';

1;
