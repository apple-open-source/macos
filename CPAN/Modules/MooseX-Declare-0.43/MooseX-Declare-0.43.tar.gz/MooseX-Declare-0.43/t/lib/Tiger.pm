use MooseX::Declare;

class Tiger { }
