package t::lib::Bar;
use warnings;
use strict;
require Exporter;
our @ISA = qw(Exporter);
our @EXPORT_OK = qw( func3 );
sub func3 { 3 }
1;
