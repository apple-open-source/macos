int c[20][30], d;

int f(int a, int b) {
  if (c[2])
  return
     (a+b)*d*c[1][1];
}
