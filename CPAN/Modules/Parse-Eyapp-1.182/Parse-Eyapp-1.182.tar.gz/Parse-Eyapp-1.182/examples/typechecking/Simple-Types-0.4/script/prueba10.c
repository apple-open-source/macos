int a,b,e[10][20];

g(int x, char y) {}
h(int x, char y) {}

int f(char c) {
char d;
 c = 'X';
 g(e[d], 'A'+c);
 if (c > 0) { 
   int d;
   d = a + b;
 }
 c = d * 2;
 return c;
}

