int a,b,e[10][20];

g() {}

int f(char c) {
char d;
 c = 'X';
 g(e[d], 'A'+c);
 { 
   int d;
   d = a + b;
 }
 a = d * 2;
 return c;
}

