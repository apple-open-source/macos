#!/usr/bin/perl -w
use Lhs;

Lhs->MAIN();
