typedef struct club 
{
    char name[30];
    int size, year;
} GROUP, CLUSTER;


typedef GROUP *PG, *GEN[10]; 

typedef void DRAWF( int, int ), *CHUCHU;

PG x;
GROUP c,d;
CLUSTER y,z;
GEN f;
DRAWF box; 
CHUCHU flup;
