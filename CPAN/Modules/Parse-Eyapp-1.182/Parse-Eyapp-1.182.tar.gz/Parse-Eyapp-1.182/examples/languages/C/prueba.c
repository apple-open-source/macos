main() {
  int a,b;

  a = 4;
}
