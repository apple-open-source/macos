our %preamble = (
  # set environment variables for ETSII
  millo => q{
    $ENV{PERL5LIB} .=q{/home/casiano/Leyappexamples/Calculator/lib:/soft/perl5lib/share/perl/5.8.8/:/soft/perl5lib/lib/perl/5.8.8:/soft/perl5lib/lib/perl/5.8:/soft/perl5lib/share/perl/5.8/};
    $ENV{PATH} .= q{:/soft/perl5lib/perl5_10_1/bin/};
});


