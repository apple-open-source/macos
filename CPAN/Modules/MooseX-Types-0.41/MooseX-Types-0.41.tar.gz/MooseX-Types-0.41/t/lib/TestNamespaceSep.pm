package TestNamespaceSep;
use warnings;
use strict;

use MooseX::Types -declare => [qw( Foo::Bar )];

1;
