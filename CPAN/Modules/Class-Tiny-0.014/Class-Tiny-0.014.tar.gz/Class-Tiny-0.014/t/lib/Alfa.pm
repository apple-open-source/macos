use 5.008001;
use strict;
use warnings;

package Alfa;

use Class::Tiny qw/foo bar/;

1;
