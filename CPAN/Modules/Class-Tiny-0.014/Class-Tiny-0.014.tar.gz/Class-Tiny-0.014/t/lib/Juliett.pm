use 5.008001;
use strict;
use warnings;

package Juliett;
use base 'Baker', 'India';

use Class::Tiny qw/kit/;

1;
