use 5.008001;
use strict;
use warnings;

package India;
use base 'Alfa';

use Class::Tiny qw/qux/;

1;
