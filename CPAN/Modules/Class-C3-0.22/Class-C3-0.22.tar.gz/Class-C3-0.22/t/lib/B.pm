package t::lib::B;
use c3;
1;