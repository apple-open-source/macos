/*
	$Id: CRCtable.h,v 1.1 2003/04/20 23:29:40 dasenbro Exp $

	File:	CRCtable.h

	Contains: Implementation of the various OS Utilities

	Version:	Apple Mail Server - Mac OS X :  $Revision: 1.1 $

	Written by: Michael Dasenbrock

	Copyright:	� 1996-2001 by Apple Computer, Inc., all rights reserved.

 	NOT_FOR_OPEN_SOURCE <to be reevaluated at a later time>

	Change History:

		$Log: CRCtable.h,v $
		Revision 1.1  2003/04/20 23:29:40  dasenbro
		Initial check-in.
		
		Revision 1.1  2002/05/30 16:51:51  dasenbro
		Initial check in.
		


	Projector History:


	To Do:

*/


#ifndef __CRCtable_h__
#define __CRCtable_h__	1

// app
#include "MailTypes.h"

#ifdef __cplusplus
extern "C" {
#endif

uInt32	UPDC32		( register char b, register uInt32 c );
uInt16	UPDC16		( char *ptr, uInt32 count, uInt16 crc );
uInt16	updcrc		( register char b, register uInt16 crc );

#ifdef __cplusplus
}
#endif


#endif // __CRCtable_h__
