/*
	$Id: CStatStr.h,v 1.1 2003/04/20 23:29:40 dasenbro Exp $

	File:		CStatStr.h

	Contains:

	Version:	Apple Mail Server - Mac OS X :  $Revision: 1.1 $

	Written by:	Michael Dasenbrock

	Copyright:	� 1999-2001 by Apple Computer, Inc., all rights reserved.

	NOT_FOR_OPEN_SOURCE <to be reevaluated at a later time>

	File Ownership:
		DRI:				David M. O'Rourke
		Other Contact:		Michael Dasenbrock
		Technology:			Apple Mail Server

	Change History:

		$Log: CStatStr.h,v $
		Revision 1.1  2003/04/20 23:29:40  dasenbro
		Initial check-in.
		
		Revision 1.6  2002/03/21 16:41:47  dasenbro
		Updated file version information.
		
		Revision 1.5  2001/06/21 20:44:46  dasenbro
		Added Change History.
		

	Projector History:


	To Do:
*/

#ifndef __CStatStr_h__
#define __CStatStr_h__	1

#include "MailTypes.h"

class CStatStr
{
public:
	static	const char*	GetStringFromList	( const uInt32 inListID, const sInt32 inIndex );
};

#endif