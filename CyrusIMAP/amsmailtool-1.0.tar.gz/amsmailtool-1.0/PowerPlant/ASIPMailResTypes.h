/*
	NOT_FOR_OPEN_SOURCE <to be reevaluated at a later time>
*/

#ifndef __ASIPMAILRESTYPES_H__
#define __ASIPMAILRESTYPES_H__

#include "MailTypes.h"

//#if !TARGET_API_MAC_OSX
//#error "This is Mac OSX only implementation of ASIP Types!!"
//#endif

typedef struct {
	int		n1;
	int		n2;
	int		n3;
	int		n4;
	int		n5;
	char	str1[40];
	char	cstr2[256];
} ResSTBT;

#endif // __ASIPMAILRESTYPES_H__