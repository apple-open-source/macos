/*
	$Id: CMailDatabase.cpp,v 1.1 2003/04/20 23:32:51 dasenbro Exp $

	File:		CMailDatabase.cpp

	Contains:	xxx put contents here xxx

	Version:	Apple Mail Server - Mac OS X :  $Revision: 1.1 $

	Written by:	David O'Rourke

	Copyright:	� 1996-2001 by Apple Computer, Inc., all rights reserved.

 	NOT_FOR_OPEN_SOURCE <to be reevaluated at a later time>

	Change History:

		$Log: CMailDatabase.cpp,v $
		Revision 1.1  2003/04/20 23:32:51  dasenbro
		Initial check-in.
		
		Revision 1.7  2002/03/21 16:41:17  dasenbro
		Updated file version information.
		
		Revision 1.6  2002/01/14 16:55:43  dasenbro
		Initial S4 updates.
		
		Revision 1.5  2001/06/21 20:50:54  dasenbro
		Updated file header info.
		
		Revision 1.4  2001/06/21 17:01:16  dasenbro
		Added Change History.
		

	Projector History:

	  <ASM2>	  6/7/99	DOR		Pass a new pointer parameter onto the base class.

	To Do:
*/

#include <ctype.h>
#include <string.h>
//#include <new.h>

#include "CBaseDatabase.h"
#include "CMailDatabase.h"


CMailDatabase::CMailDatabase ( 	const uInt32 inMinFreeDiskSpace,
								CDBMailObjectCache *inMailBaseObjectCache,
								uInt32 inPageCacheCount )
	: CBaseDatabase (inMinFreeDiskSpace, (CDBBaseObjectCache *) inMailBaseObjectCache, inPageCacheCount)
{
}


CMailDatabase::~CMailDatabase ( void )
{
}

void CMailDatabase::DoYield ( const Boolean inForceYieldFlag )
{
#pragma unused ( inForceYieldFlag )
}

void CMailDatabase::DoLockDB ( void )
{
//	fDBLock.Wait();
}

void CMailDatabase::DoReleaseDB ( void )
{
//	fDBLock.Signal();
}

Boolean CMailDatabase::IsThreadQuitting ( void )
{
	return( false );
//	return (CThread::GetCurThreadRunState() != CThread::kThreadRun);
}

