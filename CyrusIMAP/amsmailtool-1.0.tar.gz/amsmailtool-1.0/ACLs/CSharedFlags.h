/*
	$Id: CSharedFlags.h,v 1.1 2003/04/20 23:33:11 dasenbro Exp $

	File:		CSharedFlags.h

	Contains:	

	Version:	Apple Mail Server - Mac OS X :  $Revision: 1.1 $

	Written by:	Michael Dasenbrock

	Copyright:	� 1996-2001 by Apple Computer, Inc., all rights reserved.

 	NOT_FOR_OPEN_SOURCE <to be reevaluated at a later time>

	Change History:

		$Log: CSharedFlags.h,v $
		Revision 1.1  2003/04/20 23:33:11  dasenbro
		Initial check-in.
		
		Revision 1.6  2002/03/21 16:24:19  dasenbro
		Updated version information.
		
		Revision 1.5  2001/06/21 20:50:50  dasenbro
		Updated file header info.
		
		Revision 1.4  2001/06/21 16:30:36  dasenbro
		Added Change History.
		

	Projector History:


	To Do:
*/


#ifndef __CSharedFlags_h__
#define __CSharedFlags_h__ 1

#include "CExpansion.h"


typedef struct
{
	uInt32	fSharedID;
} SFlags;


class CSharedFlags : public CExpansion
{
public:
	//�Construction/Destruction
							CSharedFlags		( void );
	virtual			 	   ~CSharedFlags		( void );
			void			Done				( CSharedFlags* &inPtr );

			void			ClearIDs			( void );

			Boolean			SetSharedInfo		( ObjID inObjID );
			Boolean			DeleteSharedInfo	( ObjID inObjID );
			Boolean			IsObjectInList		( ObjID inObjID );

private:

};

#endif // __CSharedFlags_h__

