/*
	$Id: xAppResourcesStrings.h,v 1.1 2003/04/20 23:31:26 dasenbro Exp $

	File:		AppResourcesStrings.h

	Contains:	xxx put contents here xxx

	Version:	Apple Mail Server - Mac OS X :  $Revision: 1.1 $

	Written by:	Nick Brosnahan

	Copyright:	� 1996-2001 by Apple Computer, Inc., all rights reserved.

 	NOT_FOR_OPEN_SOURCE <to be reevaluated at a later time>

	Change History:

		$Log: xAppResourcesStrings.h,v $
		Revision 1.1  2003/04/20 23:31:26  dasenbro
		Initial check-in.
		
		Revision 1.21  2002/05/09 16:59:02  dasenbro
		Changed all str... calls to CUtils::Str... to be NULL safe.
		
		Revision 1.20  2002/03/21 16:41:36  dasenbro
		Updated file version information.
		
		Revision 1.19  2002/03/05 20:38:50  dasenbro
		Updated missing data text.
		
		Revision 1.18  2002/02/20 20:44:17  dasenbro
		Changed mail db name to MacOSXMailDatabase.
		
		Revision 1.17  2002/01/14 17:15:31  dasenbro
		Initial S4 updates.
		
		Revision 1.16  2001/07/09 17:05:26  dasenbro
		Added a mail log folder resource string.
		
		Revision 1.15  2001/06/21 19:48:18  dasenbro
		Added Change History.
		

	Projector History:


	To Do:
*/


#ifndef __AppResourcesStrings_h__
#define __AppResourcesStrings_h__	1

// ---------------------------------------------------------------------------
//	Application Strings
// ---------------------------------------------------------------------------

static const char *const sAppInfoStrList[] = 
{
		/*  1 */	"AppleMailServer",						// Application name
		/*    */	"AppleMail",							// Mail account folders
		/*    */	"MacOSXMailDatabase",					// Mail database name
		/*    */	"MacOSXMailDB",							// Old mail database name
		/*  5 */	"Logs",									// Log folder
		/*    */	"MailService",							// MailService folder
		/*    */	"Migration",							// Migration folder
		/*    */	"Maps",									// Map file folder
		/*    */	"AppleMailServer.Server.log",			// Server log
		/* 10 */	"AppleMailServer.SMTPIn.log",			//  log
		/*    */	"AppleMailServer.SMTPOut.log",			//  log
		/*    */	"AppleMailServer.POP.log",				//  log
		/*    */	"AppleMailServer.IMAP.log",				//  log
		/*    */	"AppleMailServer.Router.log",			//  log
		/* 15 */	"AppleMailServer.Error.log",			// Error log
		/*    */	"AppleMailServer.Migration.log",		// Migration log
		/*    */	"AppleMailServer.MigrationStatus.log",	// Migration Status log
		/*    */	"AppleMailServer.Repair.log",			// Repair log
		/*    */	"AppleMailServer.Debug.log",			// Debug log
		/* 20 */	"Mail Administrator",					// Postmaster full (real) name
		/*    */	"Postmaster",							// Postmaster user name
		/*    */	"MailService",							// Mail server prefs folder name
		/*    */	"host.com",								// POP3 Client default host name.
		/*    */	"username",								// POP3 Client default user name.
		/* 25 */	"",										// POP3 Client default password. (Bullets displayed)	}
		/*    */	"rbl.maps.vix.com",						// POP3 Client default blackhole list. "rbl.maps.vix.com"
		/*    */	"Preferences",							// Preferences folder name
		/*    */	"Mail Server Defaults.plist",			// Server prefs file name
		/*    */	"Mail Server Server Logs.plist",		// Server prefs file name
   		/* 30 */	"Mail Server Error Logs.plist",			// Server prefs file name
		/*    */	"Mail Server Local Domains.plist",		// Server prefs file name
		/*    */	"Mail Server Host Settings.plist",		// Server prefs file name
		/*    */	"Mail Server POP3 Accounts.plist",		// Server prefs file name
		/*    */	"Mail Server ETRN Hosts.plist",			// Server prefs file name
		/* 35 */	"Mail Server User Settings.plist",		// Server prefs file name
		/*    */	"xAutoStartFile",						// This will soon be gone
		/*    */	"MailStore",							// Mail Store folder name
		/*    */	"Temp",									// Temp folder name
		/*    */	"MailOut",								// SMTP out folder name
		/* 40 */	"UserAccounts",							// User mail accounts folder name
		/*    */	"%s/%u.%u.data",						// Mail "path/ID.Tag" file teplate
		/* 42 */	"%s/&u.%u.temp",						// Mail "path/ID.Tag" temp file teplate
		/* end */	""
};


// ---------------------------------------------------------------------------
//	* Dead File
// ---------------------------------------------------------------------------
/*
static const char *const sDeadFile = 
"Received: from %s by %s (%s) id %lu %s; %s\r\n"
"Date: %s\r\n"
"From: postmaster@%s\r\n"
"To: undisclosed-recipients: ;\r\n"
"Messae-id: %s\r\n"
"Subject: *** Message not found ***\r\n"
"\r\n"
"The requested message could not be found.\r\n"
"\r\n"
"Please notify the postmaster.\r\n"
"\r\n"
"Thank you.\r\n"
"";
*/

// ---------------------------------------------------------------------------
//	* Missing Message Data
// ---------------------------------------------------------------------------

static const char *const sMissingMsg = 
"From: postmaster\r\n"
"To: undisclosed-recipients: ;\r\n"
"Messae-id: %s\r\n"
"Subject: *** Message data not found ***\r\n"
"\r\n"
"The requested message could not be found.\r\n"
"\r\n"
"Please notify the postmaster.\r\n"
"\r\n"
"Thank you.\r\n"
"";

#endif // __AppResourcesStrings_h__
