/*
	$Id: AppResources.h,v 1.1 2003/04/20 23:31:26 dasenbro Exp $

	File:		AppResources.h

	Contains:	xxx put contents here xxx

	Version:	Apple Mail Server - Mac OS X :  $Revision: 1.1 $

	Written by:	Nick Brosnahan

	Copyright:	� 1996-2001 by Apple Computer, Inc., all rights reserved.

 	NOT_FOR_OPEN_SOURCE <to be reevaluated at a later time>

	Change History:

		$Log: AppResources.h,v $
		Revision 1.1  2003/04/20 23:31:26  dasenbro
		Initial check-in.
		
		Revision 1.16  2002/03/21 16:41:36  dasenbro
		Updated file version information.
		
		Revision 1.15  2002/02/20 20:43:38  dasenbro
		Changed kStrSeedDBFileName to kStrOldMailDBFileName.
		
		Revision 1.14  2002/01/14 17:15:31  dasenbro
		Initial S4 updates.
		
		Revision 1.13  2001/07/09 17:06:11  dasenbro
		Added a mail log folder const.
		
		Revision 1.12  2001/06/21 19:48:18  dasenbro
		Added Change History.
		

	Projector History:

	  <ASM5>	  2/1/99	rds		[2283763, 2301212]  Moved hard coded strings into a resource.
		 <4>	 7/24/98	MED		Changed the resource ID so admin can use the same file.
		 <3>	 7/23/98	MED		Added AppleTalk consts.
		 <2>	12/11/97	MED		Removed Old and Corrupt consts and adde a seed db name const.

	To Do:
*/


#ifndef _APPRESOURCES_H
#define _APPRESOURCES_H 1

#include "MailTypes.h"

// Application
const OSType kServerAppSignature = 'ANms';

// Mail Database type
const OSType kServerDataFileType = 'MSdb';

// Log file type
const OSType kServerLogFileType = 'TEXT';

// Log file creator
const OSType kServerLogFileCreator = 'CWIE';

// ---------------------------------------------------------------------------
//	Application Strings
// ---------------------------------------------------------------------------

enum eAppResourceIDs {
	kAppInfoListID			= 1500		// list with system related strings
};

// kAppInfoID
enum 
{
	kStrAppName						=  1,
	kStrMailFolderName				=  2,
	kStrDatabaseFileName			=  3,
	kStrOldMailDBFileName			=  4,
	kStrLogFileFolderName			=  5,

	kStrMailServiceLogFolderName	=  6,
	kStrMigrationLogFolderName		=  7,
	kStrMapFileFolderName			=  8,
	kStrServerLogFileName			=  9,
	kStrSMTPInLogFileName			= 10,

	kStrSMTPOutLogFileName			= 11,
	kStrPOPLogFileName				= 12,
	kStrIMAPLogFileName				= 13,
	kStrRouterLogFileName			= 14,
	kStrErrorLogFileName			= 15,

	kStrMigrateLogFileName			= 16,
	kStrMigrateStatusLogFileName	= 17,
	kStrRepairLogFileName			= 18,
	kStrDebugLogFileName			= 19,
	kStrPostmasterFullName			= 20,

	kStrPostmasterInetName			= 21,
	kStrNewAppName				 	= 22,
	kStrPOP3ClientDefHostName		= 23,
	kStrPOP3ClientDefUserName		= 24,
	kStrPOP3ClientDefPassword		= 25,

	kStrPOP3ClientDefBlackholeList	= 26,
	kStrPrefsFolderName				= 27,
	kStrDefaultsPrefsFileName		= 28,
	kStrServerLogsPrefsFileName		= 29,
	kStrErrorLogsPrefsFileName		= 30,

	kStrLocalDomainsPrefsFileName	= 31,
	kStrHostSetttingsPrefsFileName	= 32,
	kStrPOP3AccountsPrefsFileName	= 33,
	kStrETRNHostsPrefsFileName		= 34,
	kStrUserSettingsPrefsFileName	= 35,

	kStrLastPrefsFileName			= 36,
	kStrMailStoreFolderName			= 37,
	kStrTempFolderName				= 38,
	kStrSMTP_OutFolderName			= 39,
	kStrUserAccountsFolderName		= 40,

	kStrMailFileTemplate			= 41,	// Mail "path/name" file teplate
	kStrTempFileTemplate			= 42,	// Temp "path/name" file teplate

	kStrAppInfoIDEnd				= 99
};

#endif /* _APPRESOURCES_H */