/*
	$Id: CMailDatabase.10.1.cpp,v 1.1 2003/04/20 23:32:27 dasenbro Exp $

	File:		CMailDatabase_10_1.cpp

	Contains:	xxx put contents here xxx

	Written by:	David O'Rourke

	Copyright:	� 1996-2001 by Apple Computer, Inc., all rights reserved.

 	NOT_FOR_OPEN_SOURCE <to be reevaluated at a later time>

	Change History:

		$Log: CMailDatabase.10.1.cpp,v $
		Revision 1.1  2003/04/20 23:32:27  dasenbro
		Initial check-in.
		
		Revision 1.5  2001/06/21 20:50:54  dasenbro
		Updated file header info.
		
		Revision 1.4  2001/06/21 17:01:16  dasenbro
		Added Change History.
		

	Projector History:

	  <ASM2>	  6/7/99	DOR		Pass a new pointer parameter onto the base class.

	To Do:
*/

#include <ctype.h>
#include <string.h>

#include "CBaseDatabase.10.1.h"
#include "CMailDatabase.10.1.h"


CMailDatabase_10_1::CMailDatabase_10_1 ( const uInt32 inMinFreeDiskSpace,
										 CDBMailObjectCache_10_1 *inMailBaseObjectCache,
										 uInt32 inPageCacheCount )
	: CBaseDatabase_10_1 (inMinFreeDiskSpace, (CDBBaseObjectCache_10_1 *) inMailBaseObjectCache, inPageCacheCount)
{
}


CMailDatabase_10_1::~CMailDatabase_10_1 ( void )
{
}

void CMailDatabase_10_1::DoYield ( const Boolean inForceYieldFlag )
{
}

void CMailDatabase_10_1::DoLockDB ( void )
{
}

void CMailDatabase_10_1::DoReleaseDB ( void )
{
}

Boolean CMailDatabase_10_1::IsThreadQuitting ( void )
{
	return ( false );
}

