/*
	$Id: DirectoryInterface.h,v 1.1 2003/04/20 23:34:11 dasenbro Exp $

	File:		DirectoryInterface.h

	Contains:	class definition of a Mail User object

	Version:	Apple Mail Server - Mac OS X :  $Revision: 1.1 $

	Written by:	acheung

	Copyright:	� 1999-2001 by Apple Computer, Inc., all rights reserved.

 	NOT_FOR_OPEN_SOURCE <to be reevaluated at a later time>

	Change History:

		$Log: DirectoryInterface.h,v $
		Revision 1.1  2003/04/20 23:34:11  dasenbro
		Initial check-in.
		
		Revision 1.4  2002/03/21 16:38:52  dasenbro
		Addes network transition support.
		
		Revision 1.3  2001/06/21 20:50:55  dasenbro
		Updated file header info.
		
		Revision 1.2  2001/06/21 17:19:40  dasenbro
		Removed commented #include's.
		
		

	To Do:
*/


#ifndef DIRECTORYINTERFACE_H
#define DIRECTORYINTERFACE_H

#include "MacTypes.h"

// ##### THESE typedefs NEED TO BE FIXED
typedef		UInt32			tDirIDType;
typedef		OSType			tDirRecordType;
typedef		OSType			tDirAuthType;
typedef		const char *	tPasswordType;

#endif // DIRECTORYINTERFACE_H