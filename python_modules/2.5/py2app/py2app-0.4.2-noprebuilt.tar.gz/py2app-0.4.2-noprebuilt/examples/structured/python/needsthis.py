print "needsthis found"
print "data file: ", file('data/datafile.txt', 'r').read()
