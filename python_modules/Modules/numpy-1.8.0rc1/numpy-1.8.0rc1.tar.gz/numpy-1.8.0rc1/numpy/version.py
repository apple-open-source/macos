
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
short_version = '1.8.0rc1'
version = '1.8.0rc1'
full_version = '1.8.0rc1'
git_revision = '54149acaae5976f96a8e29c714feefcb85589313'
release = True

if not release:
    version = full_version
