# -*- coding: utf-8 -*-

"""
3 text 
lines

€
"""

from dewapp.utils import is_exe
import sys, os, os.path, shutil
