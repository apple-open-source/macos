"""  fake module """
