# Load docstring and version
from .info import __version__, LONG_DESCRIPTION as __doc__
