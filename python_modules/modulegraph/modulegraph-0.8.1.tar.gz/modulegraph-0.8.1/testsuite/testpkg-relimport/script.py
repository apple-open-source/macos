import mod
import pkg
import pkg.mod
import pkg.oldstyle
import pkg.relative
import pkg.toplevel
import pkg.subpkg.relative
import pkg.subpkg.mod2
