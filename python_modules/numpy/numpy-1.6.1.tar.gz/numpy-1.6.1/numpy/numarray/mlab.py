
from numpy.oldnumeric.mlab import *
import numpy.oldnumeric.mlab as nom

__all__ = nom.__all__

del nom
