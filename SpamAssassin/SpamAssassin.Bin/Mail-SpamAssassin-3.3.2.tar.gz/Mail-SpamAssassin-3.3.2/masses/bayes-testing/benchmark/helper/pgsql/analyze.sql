vacuum full analyze bayes_seen;
vacuum full analyze bayes_token;
vacuum full analyze bayes_vars;

