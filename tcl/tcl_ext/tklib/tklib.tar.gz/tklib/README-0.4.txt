New in Tklib 0.4
=================
                                        Tcllib 1.8
Module          Package                 New Version     Comments
------          -------                 -----------     -------------------------------
autoscroll	autoscroll              1.1		Automatic mapping of scrollbars
ctext		ctext                   3.1		A text widget with highlighting support
cursor		cursor                  0.1		Tk cursor routines
datefield	datefield               0.1		Tk datefield widget
getstring	getstring               0.1		A dialog which prompts for a string input
history		history                 0.1		Provides a history for Entry widgets
ico		ico                     0.3		Reading and writing windows icons
ipentry		ipentry                 0.1		An IP address entry widget
plotchart	Plotchart               1.1		Simple plotting and charting package
------          -------                 -----------     -------------------------------
style		style                   0.3		Theming via tk options.
		style::as               1.3
		style::lobster          0.2
------          -------                 -----------     -------------------------------
swaplist	swaplist                0.1		A dialog which allows a user to
							move options between two lists
------          -------                 -----------     -------------------------------
tablelist	tablelist		4.2		Table widget.
tkpiechart	tkpiechart              6.6		2D or 3D pie chart object in a canvas
------          -------                 -----------     -------------------------------
tooltip		tipstack                1.0		Tooltip management
		tooltip                 1.1
------          -------                 -----------     -------------------------------
widget		widget                  3.0		Megawidget package (Snidgets).
		widget::dialog          1.2
		widget::panelframe      1.0
		widget::ruler           1.0
		widget::screenruler     1.1
		widget::scrolledwindow  1.0
		widget::superframe      1.0
------          -------                 -----------     -------------------------------

Changes
=======

This is the first release of Tklib, rhus there cannot be any changes, only new code.

Unchanged Modules/Packages
==========================

Nothing can be unchanged.
