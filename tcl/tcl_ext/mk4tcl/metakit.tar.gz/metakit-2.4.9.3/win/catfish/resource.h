//{{NO_DEPENDENCIES}}
// App Studio generated include file.
// Used by CATFISH.RC
//
#define IDD_MAIN_DIALOG                 100
#define IDD_ABOUTBOX                    106
#define IDD_SETUP_DIALOG                107
#define IDC_URL_CURSOR                  110
#define IDD_FIND_DIALOG                 113
#define IDB_TREE_ICONS                  119
#define IDD_CONV_DLG                    120
#define IDD_RENAME_DLG                  122
#define IDC_CAT_LIST                    1000
#define IDC_TREE_LIST                   1002
#define IDC_STATUS                      1003
#define IDC_SETUP_BTN                   1003
#define IDC_MSG_TEXT                    1006
#define IDC_FIND_BTN                    1012
#define IDC_FILE_LIST                   1014
#define IDC_INFO_TEXT                   1017
#define IDC_ADD_BTN                     1020
#define IDC_BROWSE_BTN                  1023
#define IDC_NAME                        1024
#define IDC_SINGLE_CAT                  1027
#define IDC_MIN_DATE                    1030
#define IDC_MAX_DATE                    1031
#define IDC_MIN_SIZE                    1032
#define IDC_MAX_SIZE                    1033
#define IDC_NAME_EDIT                   1034
#define psh15                           0x040e
#define IDC_NAME_LABEL                  1038
#define IDC_SIZE_LABEL                  1039
#define chx1                            0x0410
#define IDC_DATE_LABEL                  1040
#define IDC_CAT_LABEL                   1047
#define IDC_CAT_SIZE_LABEL              1048
#define IDC_CAT_FREE_LABEL              1049
#define IDC_CAT_SAVED_LABEL             1050
#define IDC_DIR_LABEL                   1051
#define IDC_DIR_TOT_LABEL               1052
#define IDC_DIR_COUNT_LABEL             1053
#define IDC_DIR_FILES_LABEL             1054
#define IDC_DIR_NEWEST_LABEL            1055
#define IDC_LOGO_BTN                    1057
#define IDC_URL                         1058
#define IDC_EMAIL                       1059
#define IDC_DRIVES                      1063
#define IDC_ROOT                        1066
#define IDC_VOL_NAME                    1067
#define IDC_VOL_SERIAL                  1068
#define IDC_CURR_CAT                    1070
#define IDC_OLD_NAME                    1071
#define IDC_NEW_NAME_EDIT               1072
#define stc1                            0x0440
#define stc2                            0x0441
#define stc3                            0x0442
#define stc4                            0x0443
#define lst1                            0x0460
#define lst2                            0x0461
#define cmb1                            0x0470
#define cmb2                            0x0471
#define edt1                            0x0480
#define FILEOPENORD                     1536
#define IDD_WELCOME_DLG                 1537
#define ID_FIND_NEXT                    32779
#define ID_FIND_PREV                    32780
#define ID_FIND_CMD                     32785
#define ID_FILE_SETUP                   32786
#define ID_FILE_EXIT                    32787
#define ID_SORT_BY_NAME                 32788
#define ID_SORT_BY_SIZE                 32789
#define ID_SORT_BY_DATE                 32790
#define ID_SORT_REVERSE                 32791
#define ID_FILE_REFRESH                 32792
#define ID_FILE_EXPORT                  32793
#define ID_FILE_RENAME                  32805
#define ID_FILE_DELETE                  32806

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS

#define _APS_NEXT_RESOURCE_VALUE        123
#define _APS_NEXT_COMMAND_VALUE         32807
#define _APS_NEXT_CONTROL_VALUE         1074
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
