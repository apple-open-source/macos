// gnuc.h --
// $Id: gnuc.h,v 1.5 2003/11/23 01:42:51 wcvs Exp $
// This is part of Metakit, the homepage is http://www.equi4.com/metakit/

/** @file
 * Configuration header for GNU C++
 */

#define q4_GNUC 1

#if !defined (q4_BOOL)
#define q4_BOOL 1
#endif
