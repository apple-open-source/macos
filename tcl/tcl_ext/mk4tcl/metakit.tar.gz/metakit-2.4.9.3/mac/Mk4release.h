// used as prefix header in PPC release builds

#define q4_INLINE 1
