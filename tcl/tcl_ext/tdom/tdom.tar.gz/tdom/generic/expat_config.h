/* an empty/fake config.h for expat */

