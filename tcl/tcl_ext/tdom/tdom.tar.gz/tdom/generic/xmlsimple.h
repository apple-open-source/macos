
domDocument *  XML_SimpleParseDocument ( char *xml, int ignoreWhiteSpaces, 
                                         char *baseURI, Tcl_Obj *extResolver,
                                         int *pos, char **errStr );
