In order to use Snack you will have to install Tcl/Tk 8.3 first, don't forget
to tick the box to install include and library files.


Building Snack
-------------------------------------------------------------------
The win/ directory contains project files for Microsoft Visual C++ 6.0.
Simply click on snack.dsw to load the projects.


Installation
-------------------------------------------------------------------
Install the binary release of Snack first. You may have to change the 
output paths in the projects so that the dll's end up in the correct directory.
