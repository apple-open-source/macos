config_require(examples/scalar_int)
config_require(examples/watched)
config_require(examples/data_set)
config_require(examples/delayed_instance)
