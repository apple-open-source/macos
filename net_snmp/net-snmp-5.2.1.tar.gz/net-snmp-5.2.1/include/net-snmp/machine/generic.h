/*
 * chip specific definitions go here 
 */
