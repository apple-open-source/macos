/*
 * This header is here to accomodate cross compiling for
 * Microsoft Windows on a linux host using MinGW. All changes
 * should be made to mingw32.h - Andy
 */
#ifndef mingw32
#define mingw32 1
#endif

#include "mingw32.h"
