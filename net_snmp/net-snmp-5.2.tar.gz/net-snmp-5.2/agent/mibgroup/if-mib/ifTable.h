/*
 * module to include the modules
 */

config_require(if-mib/data_access/interface);
config_require(if-mib/ifTable/ifTable);
config_require(if-mib/ifTable/ifTable_interface);
config_require(if-mib/ifTable/ifTable_data_access);
