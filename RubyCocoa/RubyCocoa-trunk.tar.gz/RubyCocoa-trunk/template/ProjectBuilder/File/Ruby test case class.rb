#
#  �FILENAME�
#  �PROJECTNAME�
#
#  Created by �FULLUSERNAME� on �DATE�.
#  Copyright (c) �YEAR� �ORGANIZATIONNAME�. All rights reserved.
#

require 'test/unit'

class TC_�FILEBASENAMEASIDENTIFIER� < Test::Unit::TestCase
  def setup
    # Write setup code here.
  end
  
  def teardown
    # Write teardown code here.
  end

  def test1
    # Write first test here.
  end
end
