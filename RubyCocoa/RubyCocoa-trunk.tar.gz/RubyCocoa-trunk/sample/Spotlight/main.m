//
//  main.m
//  Spotlight
//
//  Created by Norberto Ortigoza on 9/11/05.
//  Copyright (c) 2005 __MyCompanyName__. All rights reserved.
//

#import <RubyCocoa/RBRuntime.h>

int main(int argc, const char *argv[])
{
    return RBApplicationMain("rb_main.rb", argc, argv);
}
