/* ObjcController */

#import <Cocoa/Cocoa.h>

@interface ObjcController : NSObject
{
    IBOutlet id textField;
}
- (IBAction)btnClicked:(id)sender;
@end
