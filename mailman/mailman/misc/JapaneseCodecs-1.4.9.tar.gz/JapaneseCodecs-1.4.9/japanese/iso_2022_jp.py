# Tamito KAJIYAMA <25 September 2001>

try:
    from japanese.c.iso_2022_jp import *
except ImportError:
    from japanese.python.iso_2022_jp import *
