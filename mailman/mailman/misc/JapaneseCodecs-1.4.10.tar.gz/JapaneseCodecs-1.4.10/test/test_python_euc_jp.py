# Tamito KAJIYAMA <26 September 2001>

from common_euc_jp import test

test("japanese.python.euc-jp")
