source('unittest.R')
dyn.load('simple_array_wrap.so')
source('simple_array_wrap.R')
cacheMetaData(1)
initArray()

q(save='no')


