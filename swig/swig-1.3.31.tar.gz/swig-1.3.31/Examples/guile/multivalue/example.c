void divide_l(int a, int b, int *quotient_p, int *remainder_p)
{
  *quotient_p = a/b;
  *remainder_p = a%b;
}

void divide_v(int a, int b, int *quotient_p, int *remainder_p)
{
  *quotient_p = a/b;
  *remainder_p = a%b;
}

void divide_mv(int a, int b, int *quotient_p, int *remainder_p)
{
  *quotient_p = a/b;
  *remainder_p = a%b;
}

