#define RUBY_VERSION "1.8.2"
#define RUBY_RELEASE_DATE "2004-12-25"
#define RUBY_VERSION_CODE 182
#define RUBY_RELEASE_CODE 20041225

#define RUBY_VERSION_MAJOR 1
#define RUBY_VERSION_MINOR 8
#define RUBY_VERSION_TEENY 2
#define RUBY_RELEASE_YEAR 2004
#define RUBY_RELEASE_MONTH 12
#define RUBY_RELEASE_DAY 25

RUBY_EXTERN const char ruby_version[];
RUBY_EXTERN const char ruby_release_date[];
RUBY_EXTERN const char ruby_platform[];
