require 'mkmf'

have_header( "st.h" )
create_makefile( "syck" )

