# $Id: extconf.rb,v 1.1 2002/03/22 07:20:31 aamine Exp $

require 'mkmf'
create_makefile 'racc/cparse'
