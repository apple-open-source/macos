<?php
   /** Author:       Bert-Jan Wiegeraad
       Date:         January 25, 2004
       Theme Name:   'Redmond Theme'

    **/

    global $color;
    $color[0]   = '#ece9d8';
    $color[1]   = '#800000';
    $color[2]   = '#CC0000';
    $color[3]   = '#aba899';
    $color[4]   = '#FFFFFF';
    $color[5]   = '#ece9d8';
    $color[6]   = '#FFFFFF';
    $color[7]   = '#0000CC';
    $color[8]   = '#000000';
    $color[9]   = '#aba899';
    $color[10]  = '#666666';
    $color[11]  = '#FFFFCC';
    $color[12]  = '#FFFFCC';
    $color[13]  = '#800000';
    $color[14]  = '#FF0000';
    $color[15]  = '#002266';
?>
