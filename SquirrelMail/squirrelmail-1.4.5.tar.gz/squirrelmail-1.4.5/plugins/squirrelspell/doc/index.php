<?php
/**
 * index.php -- Displays the main frameset
 *
 * Copyright (c) 1999-2005 The SquirrelMail Project Team
 * Licensed under the GNU GPL. For full terms see the file COPYING.
 *
 * Redirects to the initial SquirrelMail page.
 *
 * @version $Id: index.php,v 1.4.2.4 2005/06/04 21:49:13 jervfors Exp $
 * @package plugins
 * @subpackage squirrelspell
 */
header("Location:../../../index.php\n\n");
exit();
?>