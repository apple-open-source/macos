<?php
/**
 *  index.php -- Displays the main frameset
 *
 * Redirects to the login page.
 *
 * @copyright (c) 1999-2005 The SquirrelMail Project Team
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 * @version $Id: index.php,v 1.2.2.3 2005/02/27 23:45:26 jervfors Exp $
 * @package plugins
 * @subpackage info
 */

   header("Location:../../src/login.php\n\n");
   exit();

?>