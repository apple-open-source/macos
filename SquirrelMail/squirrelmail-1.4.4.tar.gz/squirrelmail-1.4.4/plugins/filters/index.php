<?php
/**
 *  index.php -- Displays the main frameset
 *
 *  Redirects to the login page.
 *
 * @version $Id: index.php,v 1.4.2.3 2004/12/27 15:03:57 kink Exp $
 * @copyright (c) 1999-2005 The SquirrelMail Project Team
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 * @package plugins
 * @subpackage filters
 */

   header("Location:../../src/login.php\n\n");
   exit();

?>
