<?php

/**
 * SMimeMessage.class.php
 *
 * Copyright (c) 2003-2005 The SquirrelMail Project Team
 * Licensed under the GNU GPL. For full terms see the file COPYING.
 *
 * This contains functions needed to handle mime messages.
 *
 * $Id: SMimeMessage.class.php,v 1.3.2.2 2004/12/27 15:03:42 kink Exp $
 */

class SMimeMessage {

}

?>
