<?php

/**
 * index.php
 *
 * Redirects to the index.html file.
 *
 * @copyright 1999-2010 The SquirrelMail Project Team
 * @license http://opensource.org/licenses/gpl-license.php GNU Public License
 * @version $Id: index.php 13893 2010-01-25 02:47:41Z pdontthink $
 * @package squirrelmail
 */

header('Location: index.html');

