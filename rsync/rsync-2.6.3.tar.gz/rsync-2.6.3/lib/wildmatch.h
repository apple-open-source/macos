/* wildmatch.h */

int wildmatch(const char *p, const char *text);
