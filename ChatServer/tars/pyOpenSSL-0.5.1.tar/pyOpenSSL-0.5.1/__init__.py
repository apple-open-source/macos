#
# __init__.py
#
# Copyright (C) AB Strakt 2001, All rights reserved
#
# $Id: __init__.py,v 1.2 2001/08/09 13:20:02 martin Exp $
#
"""
pyOpenSSL - A simple wrapper around the OpenSSL library
"""
import rand, crypto, SSL
