require 'xmpp4r/pubsub/helper/servicehelper'
