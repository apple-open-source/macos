# Copyright (c) 2008 Fabio Forno

from twisted.scripts.mktap import _tapHelper

Proxy65 = _tapHelper(
        "Proxy65",
        "proxy65.tap",
        "XEP 65 Bytestream Proxy Component",
        "proxy65")
