from twisted.python import util

util.moduleMovedForSplit('twisted.protocols.toc', 'twisted.words.protocols.toc',
                         'TOC protocol support', 'Words',
                         'http://twistedmatrix.com/projects/words',
                         globals())

