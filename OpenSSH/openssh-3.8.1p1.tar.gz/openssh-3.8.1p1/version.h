/* $OpenBSD: version.h,v 1.41 2004/03/20 10:40:59 markus Exp $ */

#define SSH_VERSION	"OpenSSH_3.8.1p1"
