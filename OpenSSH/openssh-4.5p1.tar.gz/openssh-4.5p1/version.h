/* $OpenBSD: version.h,v 1.48 2006/11/07 10:31:31 markus Exp $ */

#define SSH_VERSION	"OpenSSH_4.5"

#define SSH_PORTABLE	"p1"
#define SSH_RELEASE	SSH_VERSION SSH_PORTABLE
